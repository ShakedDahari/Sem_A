﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NodesProject
{
    internal class Worker : IComparable<Worker>
    {
        private string name;
        private double salary;

        public Worker(string name, double salary)
        {
            this.name = name;
            this.salary = salary;
        }

        public void SetName(string name)
        {
            this.name = name;
        }

        public string GetName()
        {
            return name;
        }

        public void SetSalary(double salary)
        {
            this.salary = salary;
        }

        public double GetSalary()
        {
            return salary;
        }

        public override string ToString()
        {
            return $"Name: {name} , Salary: {salary}";
        }

        public int CompareTo(Worker other)
        {
            return this.name.CompareTo(other.name);
        }

        public override bool Equals(object obj)
        {
            Worker w = (Worker)obj;
            return w.name == this.name && w.salary == this.salary;
        }
    }
}
