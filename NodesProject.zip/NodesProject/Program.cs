﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NodesProject
{
    internal class Program
    {
        static void Main(string[] args)
        {
            #region Menu - user option
            Console.Title = "Project - Shaked & Ofek";
            Console.ForegroundColor = ConsoleColor.DarkCyan;

            Console.WriteLine(@"\          /  |--------  |          |--------  |--------|     /\  /\     |--------    
 \        /   |          |          |          |        |    /  \/  \    |
  \  /\  /    |--------  |          |          |        |   /        \   |--------
   \/  \/     |________  |________  |________  |________|  /          \  |________");
            Console.WriteLine("Press 'Enter' to start");
            while (true)
            {
                Console.Write("* ");
                System.Threading.Thread.Sleep(300);
                if (Console.KeyAvailable && Console.ReadKey(true).Key == ConsoleKey.Enter)
                {
                    break;
                }
            }
            Console.Clear();
            menu:
            Console.ForegroundColor = ConsoleColor.DarkCyan;
            Console.WriteLine(@"What type of list do you want to create?
1. Node<int>
2. Node<Worker>
3. Node<Student>");
            try
            {
                Console.ForegroundColor = ConsoleColor.Cyan;
                int userList = int.Parse(Console.ReadLine());
                while (!(userList > 0 && userList < 4))
                {
                    Console.ForegroundColor = ConsoleColor.Red;
                    Console.WriteLine("Error, please insert correct number");
                    System.Threading.Thread.Sleep(1000);
                    Console.WriteLine("Press any key to continue");
                    Console.ReadKey();
                    Console.Clear();
                    goto menu;
                }
                Console.ForegroundColor = ConsoleColor.DarkCyan;
                switch (userList)
                {
                    case 1:
                        Console.Title = "Project - Node<int>";
                        Console.WriteLine("How many nodes in the list?");
                        Console.ForegroundColor = ConsoleColor.Cyan;
                        int numOfNodes = int.Parse(Console.ReadLine());
                        Console.ForegroundColor = ConsoleColor.DarkCyan;
                        Console.Write("Enter the 1 node: ");
                        Console.ForegroundColor = ConsoleColor.Cyan;
                        int node = int.Parse(Console.ReadLine());
                        Node<int> userNode = new Node<int>(node);
                        for (int i = 1; i < numOfNodes; i++)
                        {
                            Console.ForegroundColor = ConsoleColor.DarkCyan;
                            Console.Write($"Enter the {i + 1} node: ");
                            Console.ForegroundColor = ConsoleColor.Cyan;
                            node = int.Parse(Console.ReadLine());
                            AddLast(userNode, node);
                        }
                        System.Threading.Thread.Sleep(1000);
                        Console.Clear();
                        Console.WriteLine("Your list:");
                        Console.ForegroundColor = ConsoleColor.DarkMagenta;
                        Console.WriteLine(userNode);
                        ActivateFunctionsInt(userNode);
                        break;
                    case 2:
                        Console.Title = "Project - Node<Worker>";
                        Console.WriteLine("How many nodes in the list?");
                        Console.ForegroundColor = ConsoleColor.Cyan;
                        numOfNodes = int.Parse(Console.ReadLine());
                        Console.ForegroundColor = ConsoleColor.DarkCyan;
                        Console.WriteLine("Enter the 1 node");
                        Console.Write("Name: ");
                        Console.ForegroundColor = ConsoleColor.Cyan;
                        string name = Console.ReadLine();
                        Console.ForegroundColor = ConsoleColor.DarkCyan;
                        Console.Write("Salary: ");
                        Console.ForegroundColor = ConsoleColor.Cyan;
                        double salary = double.Parse(Console.ReadLine());
                        Worker userWorker = new Worker(name, salary);
                        Node<Worker> userWorkerNode = new Node<Worker>(userWorker);
                        for (int i = 1; i < numOfNodes; i++)
                        {
                            Console.ForegroundColor = ConsoleColor.DarkCyan;
                            Console.WriteLine($"Enter the {i + 1} node");
                            Console.Write("Name: ");
                            Console.ForegroundColor = ConsoleColor.Cyan;
                            name = Console.ReadLine();
                            Console.ForegroundColor = ConsoleColor.DarkCyan;
                            Console.Write("Salary: ");
                            Console.ForegroundColor = ConsoleColor.Cyan;
                            salary = double.Parse(Console.ReadLine());
                            userWorker = new Worker(name, salary);
                            AddLast(userWorkerNode, userWorker);
                        }
                        System.Threading.Thread.Sleep(1000);
                        Console.Clear();
                        Console.WriteLine("Your list:");
                        Console.ForegroundColor = ConsoleColor.DarkMagenta;
                        Console.WriteLine(userWorkerNode);
                        ActivateFunctionsWorker(userWorkerNode);
                        break;
                    case 3:
                        Console.Title = "Project - Node<Student>";
                        ActivateFunctionsStudent();
                        break;
                }
            }
            catch (Exception)
            {
                Console.ForegroundColor = ConsoleColor.Red;
                Console.WriteLine("Error, please insert correct number");
                System.Threading.Thread.Sleep(1000);
                Console.WriteLine("Press any key to continue");
                Console.ReadKey();
                Console.Clear();
                goto menu;
            }

            #endregion

            #region Node<int> lists
            Node<int> node1 = new Node<int>(20);
            Node<int> node2 = new Node<int>(10);
            Node<int> node3 = new Node<int>(40);
            Node<int> node4 = new Node<int>(50);
            node1.SetNext(node2);
            node2.SetNext(node3);
            node3.SetNext(node4);
            node4.SetNext(null);
            Node<int> list = node1;

            Node<int> node5 = new Node<int>(20);
            Node<int> node6 = new Node<int>(20);
            Node<int> node7 = new Node<int>(30);
            Node<int> node8 = new Node<int>(50);
            node5.SetNext(node6);
            node6.SetNext(node7);
            node7.SetNext(node8);
            node8.SetNext(null);
            Node<int> list2 = node5;
            #endregion

            #region Node<Worker> lists
            Worker w1 = new Worker("w1", 1000);
            Worker w2 = new Worker("w2", 2000);
            Worker w3 = new Worker("w3", 3000);
            Worker w4 = new Worker("w4", 4000);

            Node<Worker> n4 = new Node<Worker>(w4, null);
            Node<Worker> n3 = new Node<Worker>(w3, n4);
            Node<Worker> n2 = new Node<Worker>(w2, n3);
            Node<Worker> n1 = new Node<Worker>(w1, n2);
            Node<Worker> workerList1 = n1;

            Worker w5 = new Worker("w5", 1000);
            Worker w6 = new Worker("w6", 2000);
            Worker w7 = new Worker("w7", 3000);
            Worker w8 = new Worker("w8", 4000);

            Node<Worker> n8 = new Node<Worker>(w8, null);
            Node<Worker> n7 = new Node<Worker>(w7, n8);
            Node<Worker> n6 = new Node<Worker>(w6, n7);
            Node<Worker> n5 = new Node<Worker>(w5, n6);
            Node<Worker> workerList2 = n5;
            #endregion

            #region Node<Course> lists
            Course c1 = new Course(1, 50);
            Course c2 = new Course(2, 90);
            Course c3 = new Course(3, 85);

            Node<Course> cl3 = new Node<Course>(c3, null);
            Node<Course> cl2 = new Node<Course>(c2, cl3);
            Node<Course> cl1 = new Node<Course>(c1, cl2);
            Node<Course> courses = cl1;
            #endregion

            #region Node<Student> lists
            Student s1 = new Student("s1", cl1);
            Student s2 = new Student("s2", cl2);
            Student s3 = new Student("s3", cl3);
            Student s4 = new Student("s4", cl1);
            Student s5 = new Student("s5", cl2);
            Student s6 = new Student("s6", cl3);

            Node<Student> sl3 = new Node<Student>(s3, null);
            Node<Student> sl2 = new Node<Student>(s2, sl3);
            Node<Student> sl1 = new Node<Student>(s1, sl2);
            Node<Student> students1 = sl1;

            Node<Student> sl6 = new Node<Student>(s6, null);
            Node<Student> sl5 = new Node<Student>(s5, sl6);
            Node<Student> sl4 = new Node<Student>(s4, sl5);
            Node<Student> students2 = sl4;

            Student[] studentsArr1 = new Student[3];
            studentsArr1[0] = s1;
            studentsArr1[1] = s2;
            studentsArr1[2] = s3;

            Student[] studentsArr2 = new Student[3];
            studentsArr2[0] = s4;
            studentsArr2[1] = s5;
            studentsArr2[2] = s6;

            Node<Student[]> listStudents2 = new Node<Student[]>(studentsArr2, null);
            Node<Student[]> listStudents1 = new Node<Student[]>(studentsArr1, listStudents2);
            Node<Student[]> listOfStudents = listStudents1;

            Node<Student>[] arr = new Node<Student>[2];
            arr[0] = students1;
            arr[1] = students2;

            #endregion

            #region 22 - Check Functions Node<Worker>
            //1
            //Console.WriteLine(NumberOfNodes(workerList1));

            //2
            //PrintListValues(workerList1);
            //Console.WriteLine();

            //3
            //Console.WriteLine(AddFirst(workerList1, w5));

            //4
            //Console.WriteLine(AddLast(workerList1, w5));

            //5
            //AddAfter(n2, w5);
            //Console.WriteLine(workerList1);

            //6
            //Console.WriteLine(DeleteFirst(workerList1));

            //7
            //DeleteLast(workerList1);
            //Console.WriteLine(workerList1);

            //8
            //DeleteAfter(n1);
            //Console.WriteLine(workerList1);

            //9
            //Console.WriteLine(FirstValue(workerList1));

            //10
            //Console.WriteLine(LastValue(workerList1));

            //11
            //Console.WriteLine(ValueByIndex(workerList1, 1));

            //12
            //Console.WriteLine(Contains(workerList1, w4));

            //13
            //Console.WriteLine(IsCircularList(workerList1));

            //14
            //Console.WriteLine(ReturnNewListNoDup(workerList1));

            //15
            //Console.WriteLine(NewListAddress(workerList1));
            //Console.WriteLine(IntPtr.ReferenceEquals(workerList1, NewListAddress(workerList1))); 

            //16          
            //Console.WriteLine(ReversedList(workerList1));

            //17           
            //Console.WriteLine(SortedList(workerList1));

            //18
            //Console.WriteLine(IsListsSame(workerList1, workerList2));

            //19
            //Console.WriteLine(AllValuesOfLists(workerList1, workerList2));

            //20
            //Console.WriteLine(CombineListsNoDup(workerList1, workerList2));

            //21
            //Console.WriteLine(CombineLists(workerList1, workerList2));
            #endregion

            #region 22 - Check Functions Node<int>
            //1
            //Console.WriteLine(NumberOfNodes(list));

            //2
            //PrintListValues(list);
            //Console.WriteLine();

            //3
            //Console.WriteLine(AddFirst(list, 5));

            //4
            //Console.WriteLine(AddLast(list, 40));

            //5
            //AddAfter(node2, 25);
            //Console.WriteLine(list);

            //6
            //Console.WriteLine(DeleteFirst(list));

            //7
            //DeleteLast(list);
            //Console.WriteLine(list);

            //8
            //DeleteAfter(node1);
            //Console.WriteLine(list);

            //9
            //Console.WriteLine(FirstValue(list));

            //10
            //Console.WriteLine(LastValue(list));

            //11
            //Console.WriteLine(ValueByIndex(list, 1));

            //12
            //Console.WriteLine(Contains(list, 20));

            //13
            //Console.WriteLine(IsCircularList(list));

            //14
            //Console.WriteLine(ReturnNewListNoDup(list));

            //15
            //Console.WriteLine(NewListAddress(list));
            //Console.WriteLine(IntPtr.ReferenceEquals(list, NewListAddress(list))); 

            //16          
            //Console.WriteLine(ReversedList(list));

            //17           
            //Console.WriteLine(SortedList(list));

            //18
            //Console.WriteLine(IsListsSame(list, list2));

            //19
            //Console.WriteLine(AllValuesOfLists(list, list2));

            //20
            //Console.WriteLine(CombineListsNoDup(list, list2));

            //21
            //Console.WriteLine(CombineLists(list,list2));
            #endregion

            #region Check Functions Node<Student>
            //23
            //AverageStudents(students);

            //24
            //Console.WriteLine(OutstandingStudents(listOfStudents));

            //25
            //foreach (Student item in FailedStudents(arr))
            //{
            //    Console.WriteLine(item);
            //}

            #endregion
        }

        #region Function switch case for menu Node<int>
        public static void ActivateFunctionsInt(Node<int> list)
        {
            int funcChoice = 1;
            do
            {
                Console.ForegroundColor = ConsoleColor.DarkCyan;
                Console.WriteLine(@"Choose your action: 
0 -> Exit
1. Length of list
2. Print list values
3. Add value to start of list
4. Add value to end of list
5. Add value to middle of list
6. Delete value from start
7. Delete value from last
8. Delete value from middle
9. Return first value
10. Return last value
11. Return value by index
12. Check if value exist in list
13. Check if list is circular
14. Removes duplicate values in list
15. Returns list in other address
16. Reverse list
17. Sorted list
18. Equal Lists
19. All values of two lists
20. Combine lists no duplicate
21. Combine lists");
                try
                {
                    Console.ForegroundColor = ConsoleColor.Cyan;
                    funcChoice = int.Parse(Console.ReadLine());
                    while (funcChoice < 0 || funcChoice > 21)
                    {
                        Console.ForegroundColor = ConsoleColor.Red;
                        Console.WriteLine("Error, please insert correct input");
                        Console.ForegroundColor = ConsoleColor.Cyan;
                        funcChoice = int.Parse(Console.ReadLine());
                    }
                    Console.ForegroundColor = ConsoleColor.DarkCyan;
                    switch (funcChoice)
                    {
                        case 0:
                            return;
                        case 1:
                            Console.ForegroundColor = ConsoleColor.Cyan;
                            Console.WriteLine("Length of list:");
                            Console.ForegroundColor = ConsoleColor.DarkMagenta;
                            Console.WriteLine(NumberOfNodes(list));
                            break;
                        case 2:
                            Console.ForegroundColor = ConsoleColor.Cyan;
                            Console.WriteLine("Print list values:");
                            Console.ForegroundColor = ConsoleColor.DarkMagenta;
                            PrintListValues(list);
                            break;
                        case 3:
                            Console.Write("Enter value to add: ");
                            Console.ForegroundColor = ConsoleColor.Cyan;
                            int node = int.Parse(Console.ReadLine());
                            list = AddFirst(list, node);
                            Console.ForegroundColor = ConsoleColor.Cyan;
                            Console.WriteLine("Add value to start of list:");
                            Console.ForegroundColor = ConsoleColor.DarkMagenta;
                            Console.WriteLine(list);
                            break;
                        case 4:
                            Console.Write("Enter value to add: ");
                            Console.ForegroundColor = ConsoleColor.Cyan;
                            node = int.Parse(Console.ReadLine());
                            Console.ForegroundColor = ConsoleColor.Cyan;
                            Console.WriteLine("Add value to end of list:");
                            Console.ForegroundColor = ConsoleColor.DarkMagenta;
                            list = AddLast(list, node);
                            Console.WriteLine(list);
                            break;
                        case 5:
                            Console.Write("Enter index of node to be prev: ");
                            Console.ForegroundColor = ConsoleColor.Cyan;
                            int index = int.Parse(Console.ReadLine());
                            Console.ForegroundColor = ConsoleColor.DarkCyan;
                            Console.Write("Enter value to add: ");
                            Console.ForegroundColor = ConsoleColor.Cyan;
                            node = int.Parse(Console.ReadLine());
                            Node<int> prev = list;
                            for (int i = 0; i < index; i++)
                            {
                                prev = list.GetNext();
                            }
                            Console.ForegroundColor = ConsoleColor.Cyan;
                            Console.WriteLine("Add value to middle of list:");
                            Console.ForegroundColor = ConsoleColor.DarkMagenta;
                            AddAfter(prev, node);
                            Console.WriteLine(list);
                            break;
                        case 6:
                            Console.ForegroundColor = ConsoleColor.Cyan;
                            Console.WriteLine("Delete value from start:");
                            Console.ForegroundColor = ConsoleColor.DarkMagenta;
                            list = DeleteFirst(list);
                            Console.WriteLine(list);
                            break;
                        case 7:
                            Console.ForegroundColor = ConsoleColor.Cyan;
                            Console.WriteLine("Delete value from last:");
                            Console.ForegroundColor = ConsoleColor.DarkMagenta;
                            DeleteLast(list);
                            Console.WriteLine(list);
                            break;
                        case 8:
                            Console.Write("Enter index of node to delete: ");
                            Console.ForegroundColor = ConsoleColor.Cyan;
                            index = int.Parse(Console.ReadLine());
                            Node<int> del = list;
                            for (int i = 0; i < index; i++)
                            {
                                del = list.GetNext();
                            }
                            Console.WriteLine("Delete value from middle:");
                            Console.ForegroundColor = ConsoleColor.DarkMagenta;
                            DeleteAfter(del);
                            Console.WriteLine(list);
                            break;
                        case 9:
                            Console.ForegroundColor = ConsoleColor.Cyan;
                            Console.WriteLine("Return first value:");
                            Console.ForegroundColor = ConsoleColor.DarkMagenta;
                            Console.WriteLine(FirstValue(list));
                            break;
                        case 10:
                            Console.ForegroundColor = ConsoleColor.Cyan;
                            Console.WriteLine("Return last value:");
                            Console.ForegroundColor = ConsoleColor.DarkMagenta;
                            Console.WriteLine(LastValue(list));
                            break;
                        case 11:
                            Console.Write("Enter index of node to return: ");
                            Console.ForegroundColor = ConsoleColor.Cyan;
                            index = int.Parse(Console.ReadLine());
                            Console.WriteLine("Return value by index:");
                            Console.ForegroundColor = ConsoleColor.DarkMagenta;
                            Console.WriteLine(ValueByIndex(list, index));
                            break;
                        case 12:
                            Console.Write("Enter value to check: ");
                            Console.ForegroundColor = ConsoleColor.Cyan;
                            node = int.Parse(Console.ReadLine());
                            Console.WriteLine("Check if value exist in list:");
                            Console.ForegroundColor = ConsoleColor.DarkMagenta;
                            Console.WriteLine(Contains(list, node));
                            break;
                        case 13:
                            Console.ForegroundColor = ConsoleColor.Cyan;
                            Console.WriteLine("Check if list is circular:");
                            Console.ForegroundColor = ConsoleColor.DarkMagenta;
                            Console.WriteLine(IsCircularList(list));
                            break;
                        case 14:
                            Console.ForegroundColor = ConsoleColor.Cyan;
                            Console.WriteLine("Removes duplicate values in list:");
                            Console.ForegroundColor = ConsoleColor.DarkMagenta;
                            Console.WriteLine(ReturnNewListNoDup(list));
                            break;
                        case 15:
                            Console.ForegroundColor = ConsoleColor.Cyan;
                            Console.WriteLine("Returns list in other address:");
                            Console.ForegroundColor = ConsoleColor.DarkMagenta;
                            Console.WriteLine(NewListAddress(list));
                            break;
                        case 16:
                            Console.ForegroundColor = ConsoleColor.Cyan;
                            Console.WriteLine("Reverse list:");
                            Console.ForegroundColor = ConsoleColor.DarkMagenta;
                            Console.WriteLine(ReversedList(list));
                            break;
                        case 17:
                            Console.ForegroundColor = ConsoleColor.Cyan;
                            Console.WriteLine("Sorted list:");
                            Console.ForegroundColor = ConsoleColor.DarkMagenta;
                            Console.WriteLine(SortedList(list));
                            break;
                        case 18:
                            Node<int> userNode2 = CreateNewIntList();
                            Console.ForegroundColor = ConsoleColor.DarkCyan;
                            Console.WriteLine("Your first list:");
                            Console.ForegroundColor = ConsoleColor.DarkMagenta;
                            Console.WriteLine(list);
                            Console.ForegroundColor = ConsoleColor.DarkCyan;
                            Console.WriteLine("Your second list:");
                            Console.ForegroundColor = ConsoleColor.DarkMagenta;
                            Console.WriteLine(userNode2);
                            Console.ForegroundColor = ConsoleColor.Cyan;
                            Console.WriteLine("Equal Lists:");
                            Console.ForegroundColor = ConsoleColor.DarkMagenta;
                            Console.WriteLine(IsListsSame(list, userNode2));
                            break;
                        case 19:
                            userNode2 = CreateNewIntList();
                            Console.ForegroundColor = ConsoleColor.DarkCyan;
                            Console.WriteLine("Your first list:");
                            Console.ForegroundColor = ConsoleColor.DarkMagenta;
                            Console.WriteLine(list);
                            Console.ForegroundColor = ConsoleColor.DarkCyan;
                            Console.WriteLine("Your second list:");
                            Console.ForegroundColor = ConsoleColor.DarkMagenta;
                            Console.WriteLine(userNode2);
                            Console.ForegroundColor = ConsoleColor.Cyan;
                            Console.WriteLine("All values of two lists:");
                            Console.ForegroundColor = ConsoleColor.DarkMagenta;
                            Console.WriteLine(AllValuesOfLists(list, userNode2));
                            break;
                        case 20:
                            userNode2 = CreateNewIntList();
                            Console.ForegroundColor = ConsoleColor.DarkCyan;
                            Console.WriteLine("Your first list:");
                            Console.ForegroundColor = ConsoleColor.DarkMagenta;
                            Console.WriteLine(list);
                            Console.ForegroundColor = ConsoleColor.DarkCyan;
                            Console.WriteLine("Your second list:");
                            Console.ForegroundColor = ConsoleColor.DarkMagenta;
                            Console.WriteLine(userNode2);
                            Console.ForegroundColor = ConsoleColor.Cyan;
                            Console.WriteLine("Combine lists no duplicate:");
                            Console.ForegroundColor = ConsoleColor.DarkMagenta;
                            Console.WriteLine(CombineListsNoDup(list, userNode2));
                            break;
                        case 21:
                            userNode2 = CreateNewIntList();
                            Console.ForegroundColor = ConsoleColor.DarkCyan;
                            Console.WriteLine("Your first list:");
                            Console.ForegroundColor = ConsoleColor.DarkMagenta;
                            Console.WriteLine(list);
                            Console.ForegroundColor = ConsoleColor.DarkCyan;
                            Console.WriteLine("Your second list:");
                            Console.ForegroundColor = ConsoleColor.DarkMagenta;
                            Console.WriteLine(userNode2);
                            Console.ForegroundColor = ConsoleColor.Cyan;
                            Console.WriteLine("Combine lists:");
                            Console.ForegroundColor = ConsoleColor.DarkMagenta;
                            Console.WriteLine(CombineLists(list, userNode2));
                            break;
                    }
                }
                catch (Exception)
                {
                    Console.ForegroundColor = ConsoleColor.Red;
                    Console.WriteLine("Error, please insert correct input");
                    Console.ForegroundColor = ConsoleColor.Cyan;
                    ActivateFunctionsInt(list);
                }
                System.Threading.Thread.Sleep(1000);
                Console.WriteLine("Press any key to continue");
                Console.ReadKey();
                Console.Clear();
            } while (funcChoice != 0);
        }
        #endregion

        #region Function switch case for menu Node<Worker>
        public static void ActivateFunctionsWorker(Node<Worker> list)
        {
            int funcChoice = 1;
            do
            {
                Console.ForegroundColor = ConsoleColor.DarkCyan;
                Console.WriteLine(@"Choose your action: 
0 -> Exit
1. Length of list
2. Print list values
3. Add value to start of list
4. Add value to end of list
5. Add value to middle of list
6. Delete value from start
7. Delete value from last
8. Delete value from middle
9. Return first value
10. Return last value
11. Return value by index
12. Check if value exist in list
13. Check if list is circular
14. Removes duplicate values in list
15. Returns list in other address
16. Reverse list
17. Sorted list
18. Equal Lists
19. All values of two lists
20. Combine lists no duplicate
21. Combine lists");
                try
                {
                    Console.ForegroundColor = ConsoleColor.Cyan;
                    funcChoice = int.Parse(Console.ReadLine());
                    while (funcChoice < 0 || funcChoice > 21)
                    {
                        Console.ForegroundColor = ConsoleColor.Red;
                        Console.WriteLine("Error, please insert correct input");
                        Console.ForegroundColor = ConsoleColor.Cyan;
                        funcChoice = int.Parse(Console.ReadLine());
                    }
                    Console.ForegroundColor = ConsoleColor.DarkCyan;
                    switch (funcChoice)
                    {
                        case 0:
                            return;
                        case 1:
                            Console.ForegroundColor = ConsoleColor.Cyan;
                            Console.WriteLine("Length of list:");
                            Console.ForegroundColor = ConsoleColor.DarkMagenta;
                            Console.WriteLine(NumberOfNodes(list));
                            break;
                        case 2:
                            Console.ForegroundColor = ConsoleColor.Cyan;
                            Console.WriteLine("Print list values:");
                            Console.ForegroundColor = ConsoleColor.DarkMagenta;
                            PrintListValues(list);
                            break;
                        case 3:
                            Console.WriteLine("Enter value to add");
                            Console.Write("Name: ");
                            Console.ForegroundColor = ConsoleColor.Cyan;
                            string name = Console.ReadLine();
                            Console.ForegroundColor = ConsoleColor.DarkCyan;
                            Console.Write("Salary: ");
                            Console.ForegroundColor = ConsoleColor.Cyan;
                            double salary = double.Parse(Console.ReadLine());
                            Worker userWorker = new Worker(name, salary);
                            Console.ForegroundColor = ConsoleColor.Cyan;
                            Console.WriteLine("Add value to start of list:");
                            Console.ForegroundColor = ConsoleColor.DarkMagenta;
                            list = AddFirst(list, userWorker);
                            Console.WriteLine(list);
                            break;
                        case 4:
                            Console.WriteLine("Enter value to add");
                            Console.Write("Name: ");
                            Console.ForegroundColor = ConsoleColor.Cyan;
                            name = Console.ReadLine();
                            Console.ForegroundColor = ConsoleColor.DarkCyan;
                            Console.Write("Salary: ");
                            Console.ForegroundColor = ConsoleColor.Cyan;
                            salary = double.Parse(Console.ReadLine());
                            userWorker = new Worker(name, salary);
                            Console.ForegroundColor = ConsoleColor.Cyan;
                            Console.WriteLine("Add value to end of list:");
                            Console.ForegroundColor = ConsoleColor.DarkMagenta;
                            list = AddLast(list, userWorker);
                            Console.WriteLine(list);
                            break;
                        case 5:
                            Console.Write("Enter index of node to be prev: ");
                            Console.ForegroundColor = ConsoleColor.Cyan;
                            int index = int.Parse(Console.ReadLine());
                            Console.ForegroundColor = ConsoleColor.DarkCyan;
                            Console.WriteLine("Enter value to add");
                            Console.Write("Name: ");
                            Console.ForegroundColor = ConsoleColor.Cyan;
                            name = Console.ReadLine();
                            Console.ForegroundColor = ConsoleColor.DarkCyan;
                            Console.Write("Salary: ");
                            Console.ForegroundColor = ConsoleColor.Cyan;
                            salary = double.Parse(Console.ReadLine());
                            userWorker = new Worker(name, salary);
                            Node<Worker> prev = list;
                            for (int i = 0; i < index; i++)
                            {
                                prev = list.GetNext();
                            }
                            Console.ForegroundColor = ConsoleColor.Cyan;
                            Console.WriteLine("Add value to middle of list:");
                            Console.ForegroundColor = ConsoleColor.DarkMagenta;
                            AddAfter(prev, userWorker);
                            Console.WriteLine(list);
                            break;
                        case 6:
                            Console.ForegroundColor = ConsoleColor.Cyan;
                            Console.WriteLine("Delete value from start:");
                            Console.ForegroundColor = ConsoleColor.DarkMagenta;
                            list = DeleteFirst(list);
                            Console.WriteLine(list);
                            break;
                        case 7:
                            Console.ForegroundColor = ConsoleColor.Cyan;
                            Console.WriteLine("Delete value from last:");
                            Console.ForegroundColor = ConsoleColor.DarkMagenta;
                            DeleteLast(list);
                            Console.WriteLine(list);
                            break;
                        case 8:
                            Console.Write("Enter index of node to delete: ");
                            Console.ForegroundColor = ConsoleColor.Cyan;
                            index = int.Parse(Console.ReadLine());
                            Node<Worker> del = list;
                            for (int i = 0; i < index; i++)
                            {
                                del = list.GetNext();
                            }
                            Console.WriteLine("Delete value from middle:");
                            Console.ForegroundColor = ConsoleColor.DarkMagenta;
                            DeleteAfter(del);
                            Console.WriteLine(list);
                            break;
                        case 9:
                            Console.ForegroundColor = ConsoleColor.Cyan;
                            Console.WriteLine("Return first value:");
                            Console.ForegroundColor = ConsoleColor.DarkMagenta;
                            Console.WriteLine(FirstValue(list));
                            break;
                        case 10:
                            Console.ForegroundColor = ConsoleColor.Cyan;
                            Console.WriteLine("Return last value:");
                            Console.ForegroundColor = ConsoleColor.DarkMagenta;
                            Console.WriteLine(LastValue(list));
                            break;
                        case 11:
                            Console.Write("Enter index of node to return: ");
                            Console.ForegroundColor = ConsoleColor.Cyan;
                            index = int.Parse(Console.ReadLine());
                            Console.WriteLine("Return value by index:");
                            Console.ForegroundColor = ConsoleColor.DarkMagenta;
                            Console.WriteLine(ValueByIndex(list, index));
                            break;
                        case 12:
                            Console.WriteLine("Enter value to check");
                            Console.Write("Name: ");
                            Console.ForegroundColor = ConsoleColor.Cyan;
                            name = Console.ReadLine();
                            Console.ForegroundColor = ConsoleColor.DarkCyan;
                            Console.Write("Salary: ");
                            Console.ForegroundColor = ConsoleColor.Cyan;
                            salary = double.Parse(Console.ReadLine());
                            Console.WriteLine("Check if value exist in list:");
                            userWorker = new Worker(name, salary);
                            Console.ForegroundColor = ConsoleColor.DarkMagenta;
                            Console.WriteLine(Contains(list, userWorker));
                            break;
                        case 13:
                            Console.ForegroundColor = ConsoleColor.Cyan;
                            Console.WriteLine("Check if list is circular:");
                            Console.ForegroundColor = ConsoleColor.DarkMagenta;
                            Console.WriteLine(IsCircularList(list));
                            break;
                        case 14:
                            Console.ForegroundColor = ConsoleColor.Cyan;
                            Console.WriteLine("Removes duplicate values in list:");
                            Console.ForegroundColor = ConsoleColor.DarkMagenta;
                            Console.WriteLine(ReturnNewListNoDup(list));
                            break;
                        case 15:
                            Console.ForegroundColor = ConsoleColor.Cyan;
                            Console.WriteLine("Returns list in other address:");
                            Console.ForegroundColor = ConsoleColor.DarkMagenta;
                            Console.WriteLine(NewListAddress(list));
                            break;
                        case 16:
                            Console.ForegroundColor = ConsoleColor.Cyan;
                            Console.WriteLine("Reverse list:");
                            Console.ForegroundColor = ConsoleColor.DarkMagenta;
                            Console.WriteLine(ReversedList(list));
                            break;
                        case 17:
                            Console.ForegroundColor = ConsoleColor.Cyan;
                            Console.WriteLine("Sorted list:");
                            Console.ForegroundColor = ConsoleColor.DarkMagenta;
                            Console.WriteLine(SortedList(list));
                            break;
                        case 18:
                            Node<Worker> userWorkerNode2 = CreateNewWorkerList();
                            Console.ForegroundColor = ConsoleColor.DarkCyan;
                            Console.WriteLine("Your first list:");
                            Console.ForegroundColor = ConsoleColor.DarkMagenta;
                            Console.WriteLine(list);
                            Console.ForegroundColor = ConsoleColor.DarkCyan;
                            Console.WriteLine("Your second list:");
                            Console.ForegroundColor = ConsoleColor.DarkMagenta;
                            Console.WriteLine(userWorkerNode2);
                            Console.ForegroundColor = ConsoleColor.Cyan;
                            Console.WriteLine("Equal Lists:");
                            Console.ForegroundColor = ConsoleColor.DarkMagenta;
                            Console.WriteLine(IsListsSame(list, userWorkerNode2));
                            break;
                        case 19:
                            userWorkerNode2 = CreateNewWorkerList();
                            Console.ForegroundColor = ConsoleColor.DarkCyan;
                            Console.WriteLine("Your first list:");
                            Console.ForegroundColor = ConsoleColor.DarkMagenta;
                            Console.WriteLine(list);
                            Console.ForegroundColor = ConsoleColor.DarkCyan;
                            Console.WriteLine("Your second list:");
                            Console.ForegroundColor = ConsoleColor.DarkMagenta;
                            Console.WriteLine(userWorkerNode2);
                            Console.ForegroundColor = ConsoleColor.Cyan;
                            Console.WriteLine("All values of two lists:");
                            Console.ForegroundColor = ConsoleColor.DarkMagenta;
                            Console.WriteLine(AllValuesOfLists(list, userWorkerNode2));
                            break;
                        case 20:
                            userWorkerNode2 = CreateNewWorkerList();
                            Console.ForegroundColor = ConsoleColor.DarkCyan;
                            Console.WriteLine("Your first list:");
                            Console.ForegroundColor = ConsoleColor.DarkMagenta;
                            Console.WriteLine(list);
                            Console.ForegroundColor = ConsoleColor.DarkCyan;
                            Console.WriteLine("Your second list:");
                            Console.ForegroundColor = ConsoleColor.DarkMagenta;
                            Console.WriteLine(userWorkerNode2);
                            Console.ForegroundColor = ConsoleColor.Cyan;
                            Console.WriteLine("Combine lists no duplicate:");
                            Console.ForegroundColor = ConsoleColor.DarkMagenta;
                            Console.WriteLine(CombineListsNoDup(list, userWorkerNode2));
                            break;
                        case 21:
                            userWorkerNode2 = CreateNewWorkerList();
                            Console.ForegroundColor = ConsoleColor.DarkCyan;
                            Console.WriteLine("Your first list:");
                            Console.ForegroundColor = ConsoleColor.DarkMagenta;
                            Console.WriteLine(list);
                            Console.ForegroundColor = ConsoleColor.DarkCyan;
                            Console.WriteLine("Your second list:");
                            Console.ForegroundColor = ConsoleColor.DarkMagenta;
                            Console.WriteLine(userWorkerNode2);
                            Console.ForegroundColor = ConsoleColor.Cyan;
                            Console.WriteLine("Combine lists:");
                            Console.ForegroundColor = ConsoleColor.DarkMagenta;
                            Console.WriteLine(CombineLists(list, userWorkerNode2));
                            break;
                    }
                }
                catch (Exception)
                {
                    Console.ForegroundColor = ConsoleColor.Red;
                    Console.WriteLine("Error, please insert correct input");
                    Console.ForegroundColor = ConsoleColor.Cyan;
                    ActivateFunctionsWorker(list);
                }
                System.Threading.Thread.Sleep(1000);
                Console.WriteLine("Press any key to continue");
                Console.ReadKey();
                Console.Clear();
            } while (funcChoice != 0);
        }
        #endregion

        #region Function switch case for menu Node<Student>
        public static void ActivateFunctionsStudent()
        {
            int funcChoice = 1;
            do
            {
                Console.ForegroundColor = ConsoleColor.DarkCyan;
                Console.WriteLine(@"Choose your action: 
0 -> Exit
1. Average of students
2. List of outstanding students
3. List of failed students");
                try
                {
                    Console.ForegroundColor = ConsoleColor.Cyan;
                    funcChoice = int.Parse(Console.ReadLine());
                    while (funcChoice < 0 || funcChoice > 3)
                    {
                        Console.ForegroundColor = ConsoleColor.Red;
                        Console.WriteLine("Error, please insert correct input");
                        Console.ForegroundColor = ConsoleColor.Cyan;
                        funcChoice = int.Parse(Console.ReadLine());
                    }
                    Console.ForegroundColor = ConsoleColor.DarkCyan;
                    switch (funcChoice)
                    {
                        case 0:
                            return;
                        case 1:
                            Console.WriteLine("How many nodes in the list?");
                            Console.ForegroundColor = ConsoleColor.Cyan;
                            int numOfNodes = int.Parse(Console.ReadLine());
                            Console.ForegroundColor = ConsoleColor.DarkCyan;
                            Console.WriteLine("Enter the 1 student");
                            Console.Write("Name: ");
                            Console.ForegroundColor = ConsoleColor.Cyan;
                            string name = Console.ReadLine();
                            Console.ForegroundColor = ConsoleColor.DarkCyan;
                            Console.WriteLine("How many courses in the list?");
                            Console.ForegroundColor = ConsoleColor.Cyan;
                            int numOfCourses = int.Parse(Console.ReadLine());
                            Console.ForegroundColor = ConsoleColor.DarkCyan;
                            Console.WriteLine("Enter the 1 course");
                            Console.Write("Code: ");
                            Console.ForegroundColor = ConsoleColor.Cyan;
                            int code = int.Parse(Console.ReadLine());
                            Console.ForegroundColor = ConsoleColor.DarkCyan;
                            Console.Write("Grade: ");
                            Console.ForegroundColor = ConsoleColor.Cyan;
                            int grade = int.Parse(Console.ReadLine());
                            Course course = new Course(code, grade);
                            Node<Course> coursesList = new Node<Course>(course);
                            for (int j = 1; j < numOfCourses; j++)
                            {
                                Console.ForegroundColor = ConsoleColor.DarkCyan;
                                Console.WriteLine($"Enter the {j + 1} course");
                                Console.Write("Code: ");
                                Console.ForegroundColor = ConsoleColor.Cyan;
                                code = int.Parse(Console.ReadLine());
                                Console.ForegroundColor = ConsoleColor.DarkCyan;
                                Console.Write("Grade: ");
                                Console.ForegroundColor = ConsoleColor.Cyan;
                                grade = int.Parse(Console.ReadLine());
                                course = new Course(code, grade);
                                AddLast(coursesList, course);
                            }
                            Student student = new Student(name, coursesList);
                            Node<Student> studentsList1 = new Node<Student>(student);
                            for (int i = 1; i < numOfNodes; i++)
                            {
                                Console.ForegroundColor = ConsoleColor.DarkCyan;
                                Console.WriteLine($"Enter the {i + 1} student");
                                Console.Write("Name: ");
                                Console.ForegroundColor = ConsoleColor.Cyan;
                                name = Console.ReadLine();
                                Console.ForegroundColor = ConsoleColor.DarkCyan;
                                Console.WriteLine("How many courses in the list?");
                                Console.ForegroundColor = ConsoleColor.Cyan;
                                numOfCourses = int.Parse(Console.ReadLine());
                                Console.ForegroundColor = ConsoleColor.DarkCyan;
                                Console.WriteLine("Enter the 1 course");
                                Console.Write("Code: ");
                                Console.ForegroundColor = ConsoleColor.Cyan;
                                code = int.Parse(Console.ReadLine());
                                Console.ForegroundColor = ConsoleColor.DarkCyan;
                                Console.Write("Grade: ");
                                Console.ForegroundColor = ConsoleColor.Cyan;
                                grade = int.Parse(Console.ReadLine());
                                course = new Course(code, grade);
                                coursesList = new Node<Course>(course);
                                for (int j = 1; j < numOfCourses; j++)
                                {
                                    Console.ForegroundColor = ConsoleColor.DarkCyan;
                                    Console.WriteLine($"Enter the {j + 1} course");
                                    Console.Write("Code: ");
                                    Console.ForegroundColor = ConsoleColor.Cyan;
                                    code = int.Parse(Console.ReadLine());
                                    Console.ForegroundColor = ConsoleColor.DarkCyan;
                                    Console.Write("Grade: ");
                                    Console.ForegroundColor = ConsoleColor.Cyan;
                                    grade = int.Parse(Console.ReadLine());
                                    course = new Course(code, grade);
                                    AddLast(coursesList, course);
                                }
                                student = new Student(name, coursesList);
                                AddLast(studentsList1, student);
                            }
                            System.Threading.Thread.Sleep(1000);
                            Console.Clear();
                            Console.ForegroundColor = ConsoleColor.Cyan;
                            Console.WriteLine("Your list:");
                            Console.ForegroundColor = ConsoleColor.DarkMagenta;
                            Console.WriteLine(studentsList1);
                            Console.ForegroundColor = ConsoleColor.Cyan;
                            Console.WriteLine("Average of students:");
                            Console.ForegroundColor = ConsoleColor.DarkMagenta;
                            AverageStudents(studentsList1);
                            break;
                        case 2:
                            Student[] studentsArr = new Student[0];
                            Node<Student[]> studentsList = new Node<Student[]>(studentsArr);
                            Console.ForegroundColor = ConsoleColor.DarkCyan;
                            Console.WriteLine("How many classes in list?");
                            Console.ForegroundColor = ConsoleColor.Cyan;
                            int numClasses = int.Parse(Console.ReadLine());
                            for (int i = 0; i < numClasses; i++)
                            {
                                Console.ForegroundColor = ConsoleColor.DarkCyan;
                                Console.WriteLine($"How many students in class {i + 1}?");
                                Console.ForegroundColor = ConsoleColor.Cyan;
                                int numStudents = int.Parse(Console.ReadLine());
                                studentsArr = new Student[numStudents];
                                for (int j = 0; j < numStudents; j++)
                                {
                                    Console.ForegroundColor = ConsoleColor.DarkCyan;
                                    Console.WriteLine($"Enter the {j + 1} student");
                                    Console.Write("Name: ");
                                    Console.ForegroundColor = ConsoleColor.Cyan;
                                    name = Console.ReadLine();
                                    Console.ForegroundColor = ConsoleColor.DarkCyan;
                                    Console.WriteLine("How many courses in the list?");
                                    Console.ForegroundColor = ConsoleColor.Cyan;
                                    numOfCourses = int.Parse(Console.ReadLine());
                                    Console.ForegroundColor = ConsoleColor.DarkCyan;
                                    Console.WriteLine("Enter the 1 course");
                                    Console.Write("Code: ");
                                    Console.ForegroundColor = ConsoleColor.Cyan;
                                    code = int.Parse(Console.ReadLine());
                                    Console.ForegroundColor = ConsoleColor.DarkCyan;
                                    Console.Write("Grade: ");
                                    Console.ForegroundColor = ConsoleColor.Cyan;
                                    grade = int.Parse(Console.ReadLine());
                                    course = new Course(code, grade);
                                    coursesList = new Node<Course>(course);
                                    for (int a = 1; a < numOfCourses; a++)
                                    {
                                        Console.ForegroundColor = ConsoleColor.DarkCyan;
                                        Console.WriteLine($"Enter the {a + 1} course");
                                        Console.Write("Code: ");
                                        Console.ForegroundColor = ConsoleColor.Cyan;
                                        code = int.Parse(Console.ReadLine());
                                        Console.ForegroundColor = ConsoleColor.DarkCyan;
                                        Console.Write("Grade: ");
                                        Console.ForegroundColor = ConsoleColor.Cyan;
                                        grade = int.Parse(Console.ReadLine());
                                        course = new Course(code, grade);
                                        AddLast(coursesList, course);
                                    }
                                    student = new Student(name, coursesList);
                                    studentsArr[j] = student;
                                }
                                AddLast(studentsList, studentsArr);
                            }
                            System.Threading.Thread.Sleep(1000);
                            Console.Clear();
                            Console.ForegroundColor = ConsoleColor.Cyan;
                            Node<Student[]> finalList = studentsList;
                            Console.WriteLine("Your list:");
                            Console.ForegroundColor = ConsoleColor.DarkMagenta;
                            while (finalList != null)
                            {
                                Student[] students = finalList.GetValue();
                                if (students != null)
                                {
                                    foreach (Student item in students)
                                    {
                                        Console.WriteLine(item);
                                    }
                                }
                                finalList = finalList.GetNext();
                            }
                            Console.ForegroundColor = ConsoleColor.Cyan;
                            Console.WriteLine("List of outstanding students:");
                            Console.ForegroundColor = ConsoleColor.DarkMagenta;
                            Console.WriteLine(OutstandingStudents(studentsList));
                            break;
                        case 3:
                            Console.ForegroundColor = ConsoleColor.DarkCyan;
                            Console.WriteLine("How many classes in list?");
                            Console.ForegroundColor = ConsoleColor.Cyan;
                            numClasses = int.Parse(Console.ReadLine());
                            Node<Student>[] studentsArrOfLists = new Node<Student>[numClasses];
                            for (int i = 0; i < numClasses; i++)
                            {
                                Console.ForegroundColor = ConsoleColor.DarkCyan;
                                Console.WriteLine($"How many students in class {i + 1}?");
                                Console.ForegroundColor = ConsoleColor.Cyan;
                                int numStudents = int.Parse(Console.ReadLine());
                                studentsArr = new Student[numStudents];
                                Console.ForegroundColor = ConsoleColor.DarkCyan;
                                Console.WriteLine("Enter the 1 student");
                                Console.Write("Name: ");
                                Console.ForegroundColor = ConsoleColor.Cyan;
                                name = Console.ReadLine();
                                Console.ForegroundColor = ConsoleColor.DarkCyan;
                                Console.WriteLine("How many courses in the list?");
                                Console.ForegroundColor = ConsoleColor.Cyan;
                                numOfCourses = int.Parse(Console.ReadLine());
                                Console.ForegroundColor = ConsoleColor.DarkCyan;
                                Console.WriteLine("Enter the 1 course");
                                Console.Write("Code: ");
                                Console.ForegroundColor = ConsoleColor.Cyan;
                                code = int.Parse(Console.ReadLine());
                                Console.ForegroundColor = ConsoleColor.DarkCyan;
                                Console.Write("Grade: ");
                                Console.ForegroundColor = ConsoleColor.Cyan;
                                grade = int.Parse(Console.ReadLine());
                                course = new Course(code, grade);
                                coursesList = new Node<Course>(course);
                                for (int j = 1; j < numOfCourses; j++)
                                {
                                    Console.ForegroundColor = ConsoleColor.DarkCyan;
                                    Console.WriteLine($"Enter the {j + 1} course");
                                    Console.Write("Code: ");
                                    Console.ForegroundColor = ConsoleColor.Cyan;
                                    code = int.Parse(Console.ReadLine());
                                    Console.ForegroundColor = ConsoleColor.DarkCyan;
                                    Console.Write("Grade: ");
                                    Console.ForegroundColor = ConsoleColor.Cyan;
                                    grade = int.Parse(Console.ReadLine());
                                    course = new Course(code, grade);
                                    AddLast(coursesList, course);
                                }
                                student = new Student(name, coursesList);
                                Node<Student> studentsList2 = new Node<Student>(student);
                                for (int a = 1; a < numStudents; a++)
                                {
                                    Console.ForegroundColor = ConsoleColor.DarkCyan;
                                    Console.WriteLine($"Enter the {a + 1} student");
                                    Console.Write("Name: ");
                                    Console.ForegroundColor = ConsoleColor.Cyan;
                                    name = Console.ReadLine();
                                    Console.ForegroundColor = ConsoleColor.DarkCyan;
                                    Console.WriteLine("How many courses in the list?");
                                    Console.ForegroundColor = ConsoleColor.Cyan;
                                    numOfCourses = int.Parse(Console.ReadLine());
                                    Console.ForegroundColor = ConsoleColor.DarkCyan;
                                    Console.WriteLine("Enter the 1 course");
                                    Console.Write("Code: ");
                                    Console.ForegroundColor = ConsoleColor.Cyan;
                                    code = int.Parse(Console.ReadLine());
                                    Console.ForegroundColor = ConsoleColor.DarkCyan;
                                    Console.Write("Grade: ");
                                    Console.ForegroundColor = ConsoleColor.Cyan;
                                    grade = int.Parse(Console.ReadLine());
                                    course = new Course(code, grade);
                                    coursesList = new Node<Course>(course);
                                    for (int j = 1; j < numOfCourses; j++)
                                    {
                                        Console.ForegroundColor = ConsoleColor.DarkCyan;
                                        Console.WriteLine($"Enter the {j + 1} course");
                                        Console.Write("Code: ");
                                        Console.ForegroundColor = ConsoleColor.Cyan;
                                        code = int.Parse(Console.ReadLine());
                                        Console.ForegroundColor = ConsoleColor.DarkCyan;
                                        Console.Write("Grade: ");
                                        Console.ForegroundColor = ConsoleColor.Cyan;
                                        grade = int.Parse(Console.ReadLine());
                                        course = new Course(code, grade);
                                        AddLast(coursesList, course);
                                    }
                                    student = new Student(name, coursesList);
                                    AddLast(studentsList2, student);
                                }
                                studentsArrOfLists[i] = studentsList2;
                            }
                            System.Threading.Thread.Sleep(1000);
                            Console.Clear();
                            Console.ForegroundColor = ConsoleColor.Cyan;
                            Console.WriteLine("Your list:");
                            Console.ForegroundColor = ConsoleColor.DarkMagenta;
                            foreach (var item in studentsArrOfLists)
                            {
                                Console.WriteLine(item);
                            }
                            Console.ForegroundColor = ConsoleColor.Cyan;
                            Console.WriteLine("List of failed students:");
                            Console.ForegroundColor = ConsoleColor.DarkMagenta;
                            foreach (Student item in FailedStudents(studentsArrOfLists))
                            {
                                Console.WriteLine(item);
                            }
                            break;
                    }
                }
                catch (Exception)
                {
                    Console.ForegroundColor = ConsoleColor.Red;
                    Console.WriteLine("Error, please insert correct input");
                    Console.ForegroundColor = ConsoleColor.Cyan;
                    ActivateFunctionsStudent();
                }
                System.Threading.Thread.Sleep(1000);
                Console.WriteLine("Press any key to continue");
                Console.ReadKey();
                Console.Clear();
            } while (funcChoice != 0);
        }
        #endregion

        #region Functions to create another list for exrecises 18-21
        public static Node<int> CreateNewIntList()
        {
            Console.WriteLine("Make another list for this function");
            Console.WriteLine("How many nodes in the list?");
            Console.ForegroundColor = ConsoleColor.Cyan;
            int numOfNodes = int.Parse(Console.ReadLine());
            Console.ForegroundColor = ConsoleColor.DarkCyan;
            Console.Write("Enter the 1 node: ");
            Console.ForegroundColor = ConsoleColor.Cyan;
            int node = int.Parse(Console.ReadLine());
            Node<int> userNode = new Node<int>(node);
            for (int i = 1; i < numOfNodes; i++)
            {
                Console.ForegroundColor = ConsoleColor.DarkCyan;
                Console.Write($"Enter the {i + 1} node: ");
                Console.ForegroundColor = ConsoleColor.Cyan;
                node = int.Parse(Console.ReadLine());
                AddLast(userNode, node);
            }
            return userNode;
        }


        public static Node<Worker> CreateNewWorkerList()
        {
            Console.WriteLine("Make another list for this function");
            Console.WriteLine("How many nodes in the list?");
            Console.ForegroundColor = ConsoleColor.Cyan;
            int numOfNodes = int.Parse(Console.ReadLine());
            Console.ForegroundColor = ConsoleColor.DarkCyan;
            Console.WriteLine("Enter the 1 node");
            Console.Write("Name: ");
            Console.ForegroundColor = ConsoleColor.Cyan;
            string name = Console.ReadLine();
            Console.ForegroundColor = ConsoleColor.DarkCyan;
            Console.Write("Salary: ");
            Console.ForegroundColor = ConsoleColor.Cyan;
            double salary = double.Parse(Console.ReadLine());
            Worker userWorker2 = new Worker(name, salary);
            Node<Worker> userWorkerNode2 = new Node<Worker>(userWorker2);
            for (int i = 1; i < numOfNodes; i++)
            {
                Console.ForegroundColor = ConsoleColor.DarkCyan;
                Console.WriteLine($"Enter the {i + 1} node");
                Console.Write("Name: ");
                Console.ForegroundColor = ConsoleColor.Cyan;
                name = Console.ReadLine();
                Console.ForegroundColor = ConsoleColor.DarkCyan;
                Console.Write("Salary: ");
                Console.ForegroundColor = ConsoleColor.Cyan;
                salary = double.Parse(Console.ReadLine());
                userWorker2 = new Worker(name, salary);
                AddLast(userWorkerNode2, userWorker2);
            }
            return userWorkerNode2;
        }
        #endregion

        #region 1 - Length of list
        public static int NumberOfNodes<T>(Node<T> head)
        {
            //counts number of nodes by counter that runs on the head (list)
            int counter = 0;
            while (head != null)
            {
                counter++;
                head = head.GetNext();
            }
            return counter;
        }
        #endregion

        #region 2 - Print list
        public static void PrintListValues<T>(Node<T> list)
        {
            //prints the whole list on the same line (recoursive)
            if (list == null)
                return;
            Console.Write(list.GetValue() + " ");
            PrintListValues(list.GetNext());
        }
        #endregion

        #region 3 - Add value to start of list
        public static Node<T> AddFirst<T>(Node<T> list, T value)
        {
            //creates new node
            Node<T> newNode = new Node<T>(value);
            newNode.SetNext(list); //connects list
            list = newNode;
            return list;
        }
        #endregion

        #region 4 - Add value to end of list
        public static Node<T> AddLast<T>(Node<T> head, T value)
        {
            //creates new node and check if head is empty
            Node<T> newNode = new Node<T>(value);
            if (head == null)
                return newNode;
            //current variable (head) advances until last and adds the new node
            Node<T> current = head;
            while (current.HasNext())
            {
                current = current.GetNext();
            }
            current.SetNext(newNode);
            return head;
        }
        #endregion

        #region 5 - Add value to middle of list
        public static void AddAfter<T>(Node<T> prev, T value)
        {
            //new node in between prev and prev.GetNext()
            Node<T> newNode = new Node<T>(value);
            newNode.SetNext(prev.GetNext());
            prev.SetNext(newNode);
        }
        #endregion

        #region 6 - Delete value from start
        public static Node<T> DeleteFirst<T>(Node<T> list)
        {
            //sets list to next node and disconnects the temp
            Node<T> temp = list;
            list = list.GetNext();
            temp.SetNext(null);
            return list;
        }
        #endregion

        #region 7 - Delete value from last
        public static void DeleteLast<T>(Node<T> head)
        {
            //advancing prev and temp until temp is last 
            Node<T> prev = null;
            Node<T> temp = head;
            while (temp.HasNext())
            {
                prev = temp;
                temp = temp.GetNext();
            }
            prev.SetNext(null); //disconnects temp from list (deletes last)
        }
        #endregion

        #region 8 - Delete value from middle
        public static void DeleteAfter<T>(Node<T> prev)
        {
            //check if prev is not empty and is not last
            if (prev != null && prev.HasNext())
            {
                Node<T> temp = prev.GetNext(); //temp = note to delete
                prev.SetNext(temp.GetNext()); //prev -> temp.GetNext()
                temp.SetNext(null); //disconnects temp
            }
        }
        #endregion

        #region 9 - Return first value
        public static T FirstValue<T>(Node<T> list)
        {
            //returns first value of list
            T first = list.GetValue();
            return first;
        }
        #endregion

        #region 10 - Return last value
        public static T LastValue<T>(Node<T> list)
        {
            //advancing temp until = last node and returns value
            Node<T> temp = list;
            while (temp.GetNext() != null)
            {
                temp = temp.GetNext();
            }
            return temp.GetValue();
        }
        #endregion

        #region  11 - Return value by index
        public static T ValueByIndex<T>(Node<T> list, int index)
        {
            //advancing list until index and returns node[index]
            for (int i = 0; i < index; i++)
            {
                if (list != null)
                    list = list.GetNext();
            }
            T value = list.GetValue();
            return value;
        }
        #endregion

        #region 12 - Check if value exist in list
        public static bool Contains<T>(Node<T> list, T value)
        {
            if (list == null)
                return false;
            //advancing list to find value
            while (list != null)
            {
                if (list.GetValue().Equals(value))
                {
                    return true;
                }
                list = list.GetNext();
            }
            return false; //if not found
        }
        #endregion

        #region 13 - Check if list is circular
        public static bool IsCircularList<T>(Node<T> list)
        {
            //saves first node
            Node<T> first = list;
            while (list.HasNext()) //advancing on list
            {
                if (list.GetNext() == first) //checks every node if advanced to first
                    return true;
                list = list.GetNext();
            }
            return false; //when list is not circular
        }
        #endregion

        #region 14 - Removes duplicate values in list
        public static Node<T> ReturnNewListNoDup<T>(Node<T> list)
        {
            if (list == null)
                return null;
            Node<T> newListNoDup = new Node<T>(list.GetValue()); //insert first value to new list
            Node<T> temp = newListNoDup; //indicates position of new list
            list = list.GetNext();
            while (list != null)
            {
                if (!Contains(newListNoDup, list.GetValue())) //checks if list value exists in new list
                {   //if not exist -> creating new node to new list
                    Node<T> newNode = new Node<T>(list.GetValue());
                    temp.SetNext(newNode);
                    temp = temp.GetNext();
                }
                list = list.GetNext();
            }
            return newListNoDup;
        }
        #endregion

        #region 15 - Returns list in other address
        public static Node<T> NewListAddress<T>(Node<T> list)
        {
            Node<T> newList = new Node<T>(list.GetValue()); //creates new list with first value
            Node<T> temp = newList; //index for new list
            Node<T> newNode; //save list value
            while (list.GetNext() != null)
            {
                list = list.GetNext();
                newNode = new Node<T>(list.GetValue());
                temp.SetNext(newNode);
                temp = temp.GetNext();
            }
            return newList;
        }
        #endregion

        #region 16 - Reverse list
        public static Node<T> ReversedList<T>(Node<T> list)
        {
            Node<T> prev = null, current = list, next = null;
            while (current != null)
            {
                //switching between the last and middle node
                next = current.GetNext();
                current.SetNext(prev);
                prev = current;
                current = next;
            }
            list = prev;
            return list;
        }
        #endregion

        #region 17 - Sorted list
        public static Node<T> SortedList<T>(Node<T> list) where T : IComparable<T>
        {
            Node<T> temp = new Node<T>(default(T));
            temp.SetNext(null);
            Node<T> current = list;
            while (current != null)
            {
                Node<T> next = current.GetNext();
                Node<T> prev = temp;
                //comparing each node with the rest of a list
                while (prev.GetNext() != null && prev.GetNext().GetValue().CompareTo(current.GetValue()) < 0)
                {
                    prev = prev.GetNext();
                }
                current.SetNext(prev.GetNext()); //switching between the nodes
                prev.SetNext(current);
                current = next;
            }
            temp = temp.GetNext(); //remove the first value (default T)
            return temp;
        }
        #endregion

        #region 18 - Equal Lists
        public static bool IsListsSame<T>(Node<T> list1, Node<T> list2) where T : IComparable<T>
        {
            if (NumberOfNodes(list1) != NumberOfNodes(list2)) //check the length of lists
                return false;
            list1 = SortedList(list1); //sorts the lists
            list2 = SortedList(list2);
            while (list1 != null && list2 != null)
            {
                if (list1.GetValue().CompareTo(list2.GetValue()) != 0) //check each value of lists
                    return false;
                list1 = list1.GetNext();
                list2 = list2.GetNext();
            }
            return true;
        }
        #endregion

        #region 19 - All values of two lists
        public static Node<T> AllValuesOfLists<T>(Node<T> list1, Node<T> list2)
        {
            Node<T> newList = new Node<T>(default(T));
            newList.SetNext(list1); //add list1 to new list
            while (list2 != null)
            {
                AddLast(newList, list2.GetValue()); //add each value of list2
                list2 = list2.GetNext();
            }
            newList = newList.GetNext(); //remove first dafault value
            return newList;
        }
        #endregion

        #region 20 - Combine lists no duplicate
        public static Node<T> CombineListsNoDup<T>(Node<T> list1, Node<T> list2)
        {
            Node<T> newList = AllValuesOfLists(list1, list2); //use previous function
            newList = ReturnNewListNoDup(newList); //removes duplicates in list
            return newList;
        }
        #endregion

        #region 21 - Combine lists
        public static Node<T> CombineLists<T>(Node<T> list1, Node<T> list2)
        {
            Node<T> newList = new Node<T>(default(T)); //creating new list
            newList.SetNext(null);
            Node<T> tempList2 = list2;
            while (list1 != null)
            {
                while (list2 != null)
                {
                    if (list1.GetValue().Equals(list2.GetValue())) //check if two lists have the same value
                    {
                        AddLast(newList, list1.GetValue()); //adding the value to the newList
                    }
                    list2 = list2.GetNext();
                }
                list1 = list1.GetNext();
                list2 = tempList2;
            }
            newList = newList.GetNext(); //remove the dafault value 
            newList = ReturnNewListNoDup(newList);
            return newList;
        }
        #endregion

        #region 23 - Average of students
        public static void AverageStudents(Node<Student> students)
        {
            while (students != null)
            {
                int counter = 0;
                int sum = 0;
                Node<Course> courses = students.GetValue().GetCourses(); //saves courses of each student
                while (courses != null)
                {
                    counter++; //counter for grades
                    sum += courses.GetValue().GetGrade(); //sum of all grades for current student
                    courses = courses.GetNext();
                }
                Console.WriteLine($"{students.GetValue().GetName()}, Average: " + (double)sum / counter); //average for student
                students = students.GetNext();
            }
        }
        #endregion

        #region 24 - List of outstanding students
        public static Node<Student> OutstandingStudents(Node<Student[]> studentsList)
        {
            Node<Student> outstanding = new Node<Student>(default(Student));
            while (studentsList != null)
            {
                double maxAverage = 0;
                Node<Student> maxStudent = new Node<Student>(default(Student));
                for (int i = 0; i < studentsList.GetValue().Length; i++)
                {
                    int counter = 0;
                    double sum = 0;
                    Node<Student> student = new Node<Student>(studentsList.GetValue()[i]);
                    Node<Course> courses = studentsList.GetValue()[i].GetCourses(); //saves courses of each student
                    while (courses != null)
                    {
                        counter++; //counter for grades
                        sum += courses.GetValue().GetGrade(); //sum of all grades for current student
                        courses = courses.GetNext();
                    }
                    if ((sum / counter) > maxAverage) //saves highest average
                    {
                        maxAverage = sum / counter;
                        maxStudent = new Node<Student>(student.GetValue()); //saves best student
                    }
                }
                AddLast(outstanding, maxStudent.GetValue()); //add best student of class to list
                studentsList = studentsList.GetNext();
            }
            return outstanding;
        }
        #endregion

        #region 25 - List of failed students
        public static Student[] FailedStudents(Node<Student>[] studentsArr)
        {
            Student[] fail = new Student[studentsArr.Length];
            for (int i = 0; i < studentsArr.Length; i++)
            {
                while (studentsArr[i] != null)
                {
                    Node<Student> student = new Node<Student>(studentsArr[i].GetValue());
                    int maxFailed = 0;
                    int counter = 0;
                    Node<Course> courses = studentsArr[i].GetValue().GetCourses(); //saves courses of each student
                    while (courses != null)
                    {
                        if (courses.GetValue().GetGrade() < 56)
                            counter++; //counter for failed grades                       
                        courses = courses.GetNext();
                    }
                    if (counter > maxFailed)
                    {
                        maxFailed = counter;
                        fail[i] = student.GetValue(); //placing the max failed student in list
                    }
                    studentsArr[i] = studentsArr[i].GetNext();
                }
            }
            return fail;
        }
        #endregion
    }
}
