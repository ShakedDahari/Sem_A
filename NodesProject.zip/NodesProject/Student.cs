﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NodesProject
{
    internal class Student : IComparable<Student>
    {
        private string name;
        private Node<Course> courses;

        public Student(string name)
        {
            this.name = name;
        }

        public Student(string name, Node<Course> courses)
        {
            this.name = name;
            this.courses = courses;
        }

        public void SetName(string name)
        {
            this.name = name;
        }

        public string GetName()
        {
            return name;
        }

        public void SetCourses(Node<Course> courses)
        {
            this.courses = courses;
        }

        public Node<Course> GetCourses()
        {
            return courses;
        }

        public override string ToString()
        {
            return $"Name: {name} , Courses: {courses}";
        }

        public int CompareTo(Student other)
        {
            return this.name.CompareTo(other.name);
        }
    }
}
