﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NodesProject
{
    internal class Course :IComparable<Course>
    {
        private int code;
        private int grade;

        public Course(int code, int grade)
        {
            this.code = code;
            this.grade = grade;
        }

        public void SetCode(int code)
        {
            this.code = code;
        }

        public int GetCode()
        {
            return code;
        }

        public void SetGrade(int grade)
        {
            this.grade = grade;
        }

        public int GetGrade()
        {
            return grade;
        }

        public override string ToString()
        {
            return $"Code: {code} , Grade: {grade}";
        }

        public int CompareTo(Course other)
        {
            return this.grade.CompareTo(other.grade);
        }
    }
}
